package com.example.listentome;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Current_Year extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recording_list);

        ArrayList<Recording> file = new ArrayList<Recording>();
        file.add(new Recording("January Meeting", 5040));
        file.add(new Recording("February Meeting", 3780));

        RecordingAdapter adapter = new RecordingAdapter(this, file);

        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}