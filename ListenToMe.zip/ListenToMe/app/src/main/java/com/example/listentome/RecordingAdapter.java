package com.example.listentome;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class RecordingAdapter extends ArrayAdapter<Recording> {

    public RecordingAdapter(Activity context, ArrayList<Recording> recordings) {
        super(context, 0, recordings);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        Recording currentRecording = getItem(position);
        TextView nameTextView = (TextView) listItemView.findViewById(R.id.name_text_view);
        nameTextView.setText(currentRecording.getFileName());
        TextView lengthTextView = (TextView) listItemView.findViewById(R.id.length_text_view);
        lengthTextView.setText("" + currentRecording.getFileLength());

        return listItemView;
    }

}