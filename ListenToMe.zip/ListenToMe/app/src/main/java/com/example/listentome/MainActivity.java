package com.example.listentome;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView previous_year = (TextView)findViewById(R.id.previous_year);
        previous_year.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent previousYearIntent = new Intent(MainActivity.this, Previous_Year.class);
                startActivity(previousYearIntent);
            }
        });

        TextView current_year = (TextView)findViewById(R.id.current_year);
        current_year.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent currentYearIntent = new Intent(MainActivity.this, Current_Year.class);
                startActivity(currentYearIntent);
            }
        });
    }
    public void openPreviousYear(View view){
        Intent intent = new Intent(this, Previous_Year.class);
        startActivity(intent);
    }
    public void openCurrentYear(View view){
        Intent intent = new Intent(this, Current_Year.class);
        startActivity(intent);
    }
}