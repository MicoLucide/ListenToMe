package com.example.listentome;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class Previous_Year extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recording_list);

        ArrayList<Recording> recordings = new ArrayList<Recording>();
        recordings.add(new Recording("Pre-Election Fundraiser Speech", 5650));
        recordings.add(new Recording("November Election", 5400));
        recordings.add(new Recording("December Meeting", 5700));

        RecordingAdapter adapter = new RecordingAdapter(this, recordings);

        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}