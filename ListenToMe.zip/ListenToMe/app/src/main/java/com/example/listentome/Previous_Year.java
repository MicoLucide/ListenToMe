package com.example.listentome;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.BitSet;

import static android.media.CamcorderProfile.get;

public class Previous_Year extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recording_list);

        final ArrayList<Recording> recordings = new ArrayList<Recording>();
        recordings.add(new Recording("Pre-Election Fundraiser Speech", 5650000));
        recordings.add(new Recording("November Election", 5400000));
        recordings.add(new Recording("December Meeting", 5700000));

        RecordingAdapter adapter = new RecordingAdapter(this, recordings);

        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent=new Intent(getApplicationContext(),NowPlaying.class);
            Recording selected = recordings.get(position);
            int fileLength=selected.getFileLength();
            intent.putExtra("FILE_LENGTH", fileLength);
            startActivity(intent);
            }
        });
    }
}