package com.example.listentome;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class NowPlaying extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_playing);

        ArrayList<Recording> file = new ArrayList<>();
        file.add(new Recording("November Election", 5400000));
        file.add(new Recording("December Meeting", 5700000));
        file.add(new Recording("January Meeting", 5040000));
        file.add(new Recording("February Meeting", 3780000));

        RecordingAdapter adapter = new RecordingAdapter(this, file);



    }
}