package com.example.listentome;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.ArrayList;

public class NowPlaying extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_playing);

        ArrayList<Recording> recordings = new ArrayList<Recording>();
        RecordingAdapter adapter = new RecordingAdapter(this, recordings);
        recordings.add(new Recording("Pre-Election Fundraiser Speech", 5650000));
        recordings.add(new Recording("November Election", 5400000));
        recordings.add(new Recording("December Meeting", 5700000));
        recordings.add(new Recording("January Meeting", 5040000));
        recordings.add(new Recording("February Meeting", 3780000));

        TextView time = findViewById(R.id.length_text_view);
        int dur = getIntent().getIntExtra("FILE_LENGTH", 0);
        int hrs = (dur / 3600000);
        int mns = (dur / 60000) % 60;
        int sec = dur % 60000 / 1000;
        time.setText(String.format("%02d:%02d:%02d", hrs, mns, sec));



    }
}