package com.example.listentome;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class NowPlaying extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_playing);

        ArrayList<Recording> file = new ArrayList<>();
        file.add(new Recording("November Election", 5400));
        file.add(new Recording("December Meeting", 5700));
        file.add(new Recording("January Meeting", 5040));
        file.add(new Recording("February Meeting", 3780));

        RecordingAdapter adapter = new RecordingAdapter(this, file);

        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
