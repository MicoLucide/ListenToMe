package com.example.listentome;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.listentome.R.id.end;

public class NowPlaying extends AppCompatActivity implements View.OnClickListener {

    private SeekBar seekBar;
    private ImageButton play, previous, next;
    private MediaPlayer player;
    private Runnable runnable;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_playing);

        seekBar = findViewById(R.id.seekBar);
        play = findViewById(R.id.play);
        previous = findViewById(R.id.previous);
        next = findViewById(R.id.next);
        handler = new Handler();

        play.setOnClickListener(this);
        previous.setOnClickListener(this);
        next.setOnClickListener(this);
        player = MediaPlayer.create(this, R.raw.februarymeeting);
        player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                seekBar.setMax(player.getDuration());
                player.start();
                changeSeekBar();
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser) {
                    player.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        ArrayList<Recording> recordings = new ArrayList<>();
        recordings.add(new Recording("November Election", 5400000));
        recordings.add(new Recording("December Meeting", 5700000));
        recordings.add(new Recording("January Meeting", 5040000));
        recordings.add(new Recording("February Meeting", 3780000));

        RecordingAdapter adapter = new RecordingAdapter(this, recordings);

        TextView time = findViewById(R.id.length_text_view);
        int dur = getIntent().getIntExtra("FILE_LENGTH", 0);
        int hrs = (dur / 3600000);
        int mns = (dur / 60000) % 60;
        int sec = dur % 60000 / 1000;
        time.setText(String.format("%02d:%02d:%02d", hrs, mns, sec));

        TextView title = findViewById(R.id.name_text_view);
        int meeting = getIntent().getIntExtra("FILE_NAME", 0);
        title.setText(String.valueOf(meeting));

    }

    private void changeSeekBar() {
        seekBar.setProgress(player.getCurrentPosition());
        if (player.isPlaying()) {
            runnable = new Runnable() {
                @Override
                public void run() {
                    changeSeekBar();
                }
            };
            handler.postDelayed(runnable, 1000);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
        case R.id.play:
        if (player.isPlaying()){
            player.pause();
        }
        else {
            player.start();
            changeSeekBar();
        }
        break;
            case R.id.previous:
                if (player.isPlaying()){
                    player.seekTo(player.getCurrentPosition()-5000);
                }
                else player.reset();
                break;
            case R.id.next:
                if (player.isPlaying()) {
                    player.seekTo(player.getCurrentPosition()+5000);
                }
                else player.seekTo(end);
        }
}}