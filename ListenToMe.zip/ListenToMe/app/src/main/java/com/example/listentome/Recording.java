package com.example.listentome;

import android.view.View;

public class Recording {
    private String mFileName;
    private int mFileLength;

    public Recording(String fileName, int fileLength) {
        mFileName = fileName;
        mFileLength = fileLength;
    }

    public String getFileName() {
        return mFileName;
    }
    public int getFileLength() {
        return mFileLength;
    }
}
